
import "dotenv/config";

const config = {
    user : process.env.SQLUser,
    password : process.env.SQLContra, 
    server : process.env.SQLServer, 
    database : process.env.SQLDatabase,
    options : {
        trustServerCertificate : true,
        trsutedConnection : true
    }
}

export default config;
