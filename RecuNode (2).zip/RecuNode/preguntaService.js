import config from "./dbconfig.js";
import mssql from "mssql";

class service {
    static conseguirFechaActual = () => {
        const fecha = new Date().toISOString().replace(/T/, ' ').replace(/\..+/, '');
        return fecha;
    }

    static crearPregunta = async (pregunta) => {
        let conexion = await mssql.connect(config);
        try {
            let fecha = this.conseguirFechaActual();
            let result = await conexion
            .input("pregunta", pregunta.pregunta)
            .input("opcion1", pregunta.opcion1)
            .input("opcion2", pregunta.opcion2)
            .input("opcion3", pregunta.opcion3)
            .input("opcion4", pregunta.opcion4)
            .input("respuestaCorrecta", pregunta.respuestaCorrecta)
            .input("fechaDeCreacion", fecha)
            .execute("INSERT INTO Preguntas(pregunta, opcion1, opcion2, opcion3, opcion4, respuestaCorrecta, fechaDeCreacion) VALUES (@pregunta, @opcion1, @opcion2, @opcion3, @opcion4, @respuestaCorrecta, @fechaDeCreacion)");
        } catch (e) {
            console.log(e);
        }
    }

    static actualizarPregunta = async (pregunta) => {
        let conexion = await mssql.connect(config);
        try {
            let result = await conexion
            .input("id", pregunta.id)
            .input("pregunta", pregunta.pregunta)
            .input("opcion1", pregunta.opcion1)
            .input("opcion2", pregunta.opcion2)
            .input("opcion3", pregunta.opcion3)
            .input("opcion4", pregunta.opcion4)
            .input("respuestaCorrecta", pregunta.respuestaCorrecta)
            .execute("UPDATE Preguntas SET pregunta = @pregunta, opcion1 = @opcion1, opcion2 = @opcion2, opcion3 = @opcion3, opcion4 = @opcion4, respuestaCorrecta = @respuestaCorrecta WHERE id = @id");
        } catch (e) {
            console.log(e);
        }
    }

    static eliminarPregunta = async (idPregunta) => {
        let conexion = await mssql.connect(config);
        try {
            let result = await conexion
            .input("id", pregunta.id)
            .execute("DELETE FROM Preguntas WHERE id = @id");
        } catch (e) {
            console.log(e);
        }
    }

    static getAllPreguntas = async () => {
        let conexion = await mssql.connect(config);
        try {
            let result = await conexion.query("SELECT * FROM Preguntas");
            return result.recordset;
        } catch (e) {
            console.log(e);
        }
    }

    static crearRespuesta = async (respuesta) => {
        let conexion = await mssql.connect(config);
        try {
            let fecha = this.conseguirFechaActual(); 
            let result = await conexion
            .input("fkPregunta", respuesta.fkPregunta)
            .input("respuestaSeleccionada", pregunta.respuestaSeleccionada)
            .input("esRespuestaCorrecta", pregunta.esRespuestaCorrecta)
            .input("fechaCreacion", fecha)
            .execute("INSERT INTO Respuestas(fkPregunta, respuestaSeleccionada, esRespuestaCorrecta, fechaCreacion) VALUES (@fkPregunta, @respuestaSeleccionada, @esRespuestaCorrecta, @fechaCreacion)");
        } catch (e) {
            console.log(e);
        }
    }
}

export default service;