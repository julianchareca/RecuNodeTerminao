import express from "express";
import service from "./preguntaService.js";

const app = express();

app.post("/preguntas", async (req, res) => {
    await service.crearPregunta(req.body.pregunta);
    res.status(200).json("Listo");
})

app.put("/preguntas", async (req, res) => {
    await service.actualizarPregunta(req.body.pregunta);
    res.status(200).json("Listo");
})

app.delete("/preguntas", async (req, res) => {
    await service.eliminarPregunta(req.body.preguntaId);
    res.status(200).json("Listo");
})

app.get("/preguntas/azar", async (req, res) => {
    let preguntas = await service.getAllPreguntas();
    let numero = Math.floor(Math.random() * preguntas.length);
    res.status(200).json(preguntas[numero]);
})

app.get("/preguntas", async (req, res) => {
    let preguntas = await service.getAllPreguntas();
    res.status(200).json(preguntas);
})


app.post("/respuestas", async (req, res) => {
    await service.crearRespuesta(req.body.respuesta);
    res.status(200).json("Listo");
})
app.listen(3000, ()=>{
    console.log('Listening on port 3000');
})